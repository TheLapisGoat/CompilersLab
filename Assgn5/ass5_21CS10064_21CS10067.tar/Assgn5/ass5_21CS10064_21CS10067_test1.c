int main() {
    int n1, n2, n3;
    float f1, f2, f3;
    
    n1 = n2 << 2;
    n2 = n1 >> 2;
    n3 = n1 * n2 / f3;
    f2 = f1 + (-n2 - n3) * f1;
    n1 = n2 ^ n3;
    n2 = (n1 & n2) | n3;
    n3 = n1 & (n2 | n3);

    int x = 120;
    int y = 17;
    char ch = 'c', d = 'a'; 
    
    return 0;
}